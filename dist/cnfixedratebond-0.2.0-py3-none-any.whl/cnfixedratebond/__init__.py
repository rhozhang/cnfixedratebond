# fixed-rate bond
# method names mimic to MS Excel

import datetime
from numpy import exp

def isleap(yr: int) -> bool:
    '''
    is yr a leap year?
    param yr: yyyy
    return: bool
    '''
    return (yr % 4 == 0 and yr % 100 != 0) or (yr % 400 == 0)

def includeleapday(d1: datetime.date, d2:datetime.date, *, closed: str = 'both') -> bool:
    '''
    if there is leap day (Feb 29) between d1 and d2
    param:
        - d1: start date
        - d2: end date
        - closed: 'both', 'left', 'right', 'neither'
    return: bool
    '''
    adj = {
        'both': (0, 0),
        'left': (0, -1),
        'right': (-1, 0),
        'neither': (-1, -1)
    }
    d1 += datetime.timedelta(days = adj[closed][0])
    d2 += datetime.timedelta(days = adj[closed][1])
    i = 0
    while (d := d1 + datetime.timedelta(days = i)) <= d2:
        if d.month == 2 and d.day == 29:
            return True
        i += 1
    return False
        
def addmons(d: datetime.date, n: int) -> datetime.date:
    '''
    add n months to d
    param:
        - d: start date
        - n: number of months to add    
    '''
    d_max = (31, 28 + isleap(d.year), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    y = d.year + (d.month + n - 1) // 12
    m = (d.month + n - 1) % 12 + 1
    d = min(d.day, d_max[m - 1])
    return datetime.date(y, m, d)

class FixedRateBond:
    def __init__(self, maturity: datetime.date, rate: float, freq: int, issuedate: datetime.date = None):
        self.maturitydate = maturity
        self.couponrate = rate
        self.frequency = freq
        self.issuedate = issuedate
    def yearsresidual(self, settlement: datetime.date) -> float:
        '''
        residual maturity from settlementdate to maturitydate in years
        param:
            - settlement: settlement date
        '''
        # actual days between settlementdate and maturitydate
        ds = (self.maturitydate - settlement).days
        # average days per year
        y1 = settlement.year
        y2 = self.maturitydate.year
        ly = [isleap(y) for y in range(y1, y2 + 1)]
        davg = 365 + sum(ly) / len(ly)
        return round(ds / davg, 4)
    def coupnum(self, settlement: datetime.date) -> int:
        '''
        number of coupon payments
        '''
        n = int(self.yearsresidual(settlement) * self.frequency)
        # NB: n * 12 / self.frequency returns a float, not an int
        if addmons(self.maturitydate, -n * 12 // self.frequency) > settlement:
            n += 1
        if addmons(self.maturitydate, -(n - 1) * 12 // self.frequency) < settlement:
            n -= 1
        return n
    def couppcd(self, settlement: datetime.date) -> datetime.date:
        '''
        previous coupon payment date
        '''
        n = self.coupnum(settlement)
        return addmons(self.maturitydate, -n * 12 // self.frequency)
    def coupncd(self, settlement: datetime.date) -> datetime.date:
        '''
        next coupon payment date
        '''
        n = self.coupnum(settlement)
        return addmons(self.maturitydate, -(n - 1) * 12 // self.frequency)
    def accrint(self, settlement: datetime.date, *, dcc: str = 'act/act') -> float:
        '''
        accrued interest from previous coupon payment date to settlement date
        dcc: kwarg, day count convention, "act/act", "act/365", "nl/365", ...
        '''
        dcc = dcc.lower()
        pcd = self.couppcd(settlement)
        ncd = self.coupncd(settlement)
        if dcc in ("act/act", "actual/actual", "ib"):
            ai = (settlement - pcd).days / (ncd - pcd).days * self.couponrate * 100 / self.frequency
        elif dcc in ("act/365", "actual/365", "sh", "sse", "shanghai"):
            ai = (settlement - pcd).days / 365 * self.couponrate * 100
        elif dcc in ("nl/365", "sz", "szse", "shenzhen"):
            ai = ((settlement - pcd).days - includeleapday(pcd, settlement)) / 365 * self.couponrate * 100
        else:
            raise ValueError("dcc not available")
        return ai
    def __cfs(self, settlement: datetime.date) -> tuple[list[datetime.date], list[float], list[float]]:
        '''
        private method, return tuple of lists:
            - payment dates
            - periods from settlement date to each coupon payment date
            - cash flows paid
        '''
        n = self.coupnum(settlement)
        pcd = self.couppcd(settlement)
        ncd = self.coupncd(settlement)
        # periods from settlement date to ncd
        a = (ncd - settlement).days / (ncd - pcd).days
        paydate = [addmons(self.maturitydate, -(n - t) * 12 // self.frequency) for t in range(1, n + 1)]
        t = [a + i for i in range(n)]
        cf = [self.couponrate * 100 / self.frequency] * n
        cf[n - 1] += 100
        return (paydate, t, cf)
    def price(self, settlement: datetime.date, yld: float, *, dcc: str = 'act/act') -> float:
        '''
        theoretical clean price, i.e. intrinsic value
        yld: discount rate, or theoretical yield
        '''
        y = yld / self.frequency
        i = self.couponrate / self.frequency
        n = self.coupnum(settlement)
        pcd = self.couppcd(settlement)
        ncd = self.coupncd(settlement)
        a = (ncd - settlement).days / (ncd - pcd).days
        dirty = (100 * i * (1 + 1/y - 1/(y * (1 + y)**(n - 1))) + 100 / (1 + y)**(n - 1)) / (1 + y)**a if y != 0 else 100 + 100 * i * n
        ai = self.accrint(settlement)
        return round(dirty - ai, 3)
    def ytm(self, settlement: datetime.date, prc: float, *, dcc: str = "act/act") -> float:
        '''
        yield to maturity with bisection method
        NB: yield is python's reserved keyword, we can not use it as function name (Excel yield())
        prc: clean price (market)
        '''
        ylower, yupper = 0.00, 1.00
        iter, itermax = 0, 500
        tol = 1e-6
        ym = (ylower + yupper) / 2

        while abs(self.price(settlement, ym, dcc = dcc) - prc) > tol:
            if (self.price(settlement, ylower, dcc = dcc) - prc) * (self.price(settlement, ym, dcc = dcc) - prc) < 0:
                yupper = ym
            else:
                ylower = ym
            ym = (ylower + yupper) / 2
            iter += 1
            if iter >= itermax:
                raise Exception("could not find root after " + itermax + " iterations")
        return ym

    def duration(self, settlement: datetime.date, yld: float, *, continuous: bool = False) -> dict[str: float]:
        '''
        duration: dict of 3 values (Macaulay, modified, money)
        '''
        bcfs = self.__cfs(settlement)
        y = yld / self.frequency
        n = len(bcfs[2])
        dcfs = [bcfs[2][t] * exp(-bcfs[1][t] * y) for t in range(n)] if continuous else [bcfs[2][t] / (1 + y)**bcfs[1][t] for t in range(n)]
        p = sum(dcfs)
        tdcfs = [bcfs[1][t] * dcfs[t] for t in range(n)]

        macd = sum(tdcfs) / (p * self.frequency)
        modd = macd if continuous else macd / (1 + y)
        mond = modd * p
        return {"macaulay": macd, "modified": modd, "money": mond}

    def convexity(self, settlement: datetime.date, yld: float, *, continuous: bool = False) -> float:
        '''
        convexity
        '''
        bcfs = self.__cfs(settlement)
        y = yld / self.frequency
        n = len(bcfs[2])
        dcfs = [bcfs[2][t] * exp(-bcfs[1][t] * y) for t in range(n)] if continuous else [bcfs[2][t] / (1 + y)**bcfs[1][t] for t in range(n)]
        p = sum(dcfs)
        ttdcfs = [(bcfs[1][t])**2 * dcfs[t] for t in range(n)] if continuous else [bcfs[1][t] * (bcfs[1][t] + 1) * dcfs[t] for t in range(n)]
        res = sum(ttdcfs) / (p * (self.frequency)**2) if continuous else sum(ttdcfs) / (p * (1 + y)**2 * (self.frequency)**2)
        return res
